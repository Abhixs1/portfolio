import { BrowserRouter } from "react-router-dom";
import { About, Contact, Experience, Feedbacks, Hero, Navbar, Tech, Works, StarsCanvas } from "./components";

const App = () => {
  return (
    <BrowserRouter>
      <div className='relative z-0 bg-primary'>

        {/* Hero Section with background pattern */}
        <div className='bg-hero-pattern bg-cover bg-no-repeat bg-center'>
          <Navbar />
          <Hero />
        </div>

        {/* All sections wrapped in stars */}
        <div className='relative z-0'>
          <StarsCanvas />

          {/* About */}
          <div className='relative'>
            <div className='absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#915EFF] to-transparent opacity-50' />
            <About />
          </div>

          {/* Experience */}
          <div className='relative'>
            <div className='absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#00CEA8] to-transparent opacity-30' />
            <Experience />
          </div>

          {/* Tech */}
          <div className='relative'>
            <div className='absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#915EFF] to-transparent opacity-30' />
            <Tech />
          </div>

          {/* Works / Projects */}
          <div className='relative'>
            <div className='absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#00CEA8] to-transparent opacity-30' />
            <Works />
          </div>

          {/* Testimonials */}
          <div className='relative'>
            <div className='absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#915EFF] to-transparent opacity-30' />
            <Feedbacks />
          </div>

          {/* Contact */}
          <div className='relative'>
            <div className='absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#00CEA8] to-transparent opacity-50' />
            <Contact />
          </div>

          {/* Footer */}
          <footer className='relative z-10 text-center py-8 border-t border-[#915EFF]/20'>
            <p className='text-secondary text-[14px]'>
              Designed & Built by{" "}
              <span className='text-[#915EFF] font-semibold'>Abhishek Kumar</span>
            </p>
            <div className='flex justify-center gap-6 mt-4'>
              <a
                href='https://github.com/Abhixs1'
                target='_blank'
                rel='noopener noreferrer'
                className='flex items-center gap-2 text-secondary hover:text-white transition-colors duration-200 text-[13px]'
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"/>
                </svg>
                GitHub
              </a>
              <a
                href='https://linkedin.com/in/abhishek-kumar-here'
                target='_blank'
                rel='noopener noreferrer'
                className='flex items-center gap-2 text-secondary hover:text-[#915EFF] transition-colors duration-200 text-[13px]'
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
                LinkedIn
              </a>
              <a
                href='mailto:abhishekbit2002@gmail.com'
                className='flex items-center gap-2 text-secondary hover:text-[#00CEA8] transition-colors duration-200 text-[13px]'
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                abhishekbit2002@gmail.com
              </a>
            </div>
            <p className='text-secondary/40 text-[12px] mt-4'>
              © {new Date().getFullYear()} Abhishek Kumar. All rights reserved.
            </p>
          </footer>

        </div>
      </div>
    </BrowserRouter>
  );
};

export default App;